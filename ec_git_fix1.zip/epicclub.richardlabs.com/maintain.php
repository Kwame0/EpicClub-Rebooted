<?php
 // include header
 include($_SERVER['DOCUMENT_ROOT'] . '/EpicClubRebootMisc/header.php');
?>

<center style='font-family:Arial, Terminal;'>
	<text style='font-size:60px;font-weight:bold;position:fixed;left:20%;top:35%;'>EpicClub is in<br>Maintenance<br><br>
		<text style='color:grey;font-size:25px;'>Come back later while we maintain the website!</text>
	</text>
	<img style='position:fixed;left:60%;top:30%;' src='../EpicClubRebootMisc/IMGS/maintain.png'></img>
</center>


wow this page really wasnt needed in the script. hi there! <BR>


Author Kwame ~  <3 CherBear ~ <3 - Author Kwame ~  <3 CherBear ~ <3 - Author Kwame ~  <3 CherBear ~ <3 - Author Kwame ~  <3 CherBear ~ <3 -
Author Kwame ~  <3 CherBear ~ <3 - Author Kwame ~  <3 CherBear ~ <3 -Author Kwame ~  <3 CherBear ~ <3 - Author Kwame ~  <3 CherBear ~ <3 -
Author Kwame ~  <3 CherBear ~ <3 - Author Kwame ~  <3 CherBear ~ <3 -Author Kwame ~  <3 CherBear ~ <3 - Author Kwame ~  <3 CherBear ~ <3 -
Author Kwame ~  <3 CherBear ~ <3 - Author Kwame ~  <3 CherBear ~ <3 -Author Kwame ~  <3 CherBear ~ <3 - Author Kwame ~  <3 CherBear ~ <3 -
Author Kwame ~  <3 CherBear ~ <3 - Author Kwame ~  <3 CherBear ~ <3 -Author Kwame ~  <3 CherBear ~ <3 - Author Kwame ~  <3 CherBear ~ <3 -
Author Kwame ~  <3 CherBear ~ <3 - Author Kwame ~  <3 CherBear ~ <3 -Author Kwame ~  <3 CherBear ~ <3 - Author Kwame ~  <3 CherBear ~ <3 -
Author Kwame ~  <3 CherBear ~ <3 - Author Kwame ~  <3 CherBear ~ <3 -Author Kwame ~  <3 CherBear ~ <3 - Author Kwame ~  <3 CherBear ~ <3 -
Author Kwame ~  <3 CherBear ~ <3 - Author Kwame ~  <3 CherBear ~ <3 -Author Kwame ~  <3 CherBear ~ <3 - Author Kwame ~  <3 CherBear ~ <3 -
Author Kwame ~  <3 CherBear ~ <3 - Author Kwame ~  <3 CherBear ~ <3 -Author Kwame ~  <3 CherBear ~ <3 - Author Kwame ~  <3 CherBear ~ <3 -
Author Kwame ~  <3 CherBear ~ <3 - Author Kwame ~  <3 CherBear ~ <3 -Author Kwame ~  <3 CherBear ~ <3 - Author Kwame ~  <3 CherBear ~ <3 -
Author Kwame ~  <3 CherBear ~ <3 - Author Kwame ~  <3 CherBear ~ <3 -Author Kwame ~  <3 CherBear ~ <3 - Author Kwame ~  <3 CherBear ~ <3 -
Author Kwame ~  <3 CherBear ~ <3 - Author Kwame ~  <3 CherBear ~ <3 -Author Kwame ~  <3 CherBear ~ <3 - Author Kwame ~  <3 CherBear ~ <3 -
Author Kwame ~  <3 CherBear ~ <3 - Author Kwame ~  <3 CherBear ~ <3 -Author Kwame ~  <3 CherBear ~ <3 - Author Kwame ~  <3 CherBear ~ <3 -
Author Kwame ~  <3 CherBear ~ <3 - Author Kwame ~  <3 CherBear ~ <3 -Author Kwame ~  <3 CherBear ~ <3 - Author Kwame ~  <3 CherBear ~ <3 -
Author Kwame ~  <3 CherBear ~ <3 - Author Kwame ~  <3 CherBear ~ <3 -Author Kwame ~  <3 CherBear ~ <3 - Author Kwame ~  <3 CherBear ~ <3 -
Author Kwame ~  <3 CherBear ~ <3 - Author Kwame ~  <3 CherBear ~ <3 - Author Kwame ~  <3 CherBear ~ <3 - Author Kwame ~  <3 CherBear ~ <3 -
Author Kwame ~  <3 CherBear ~ <3 - Author Kwame ~  <3 CherBear ~ <3 -Author Kwame ~  <3 CherBear ~ <3 - Author Kwame ~  <3 CherBear ~ <3 -
Author Kwame ~  <3 CherBear ~ <3 - Author Kwame ~  <3 CherBear ~ <3 -Author Kwame ~  <3 CherBear ~ <3 - Author Kwame ~  <3 CherBear ~ <3 -
Author Kwame ~  <3 CherBear ~ <3 - Author Kwame ~  <3 CherBear ~ <3 -Author Kwame ~  <3 CherBear ~ <3 - Author Kwame ~  <3 CherBear ~ <3 -
Author Kwame ~  <3 CherBear ~ <3 - Author Kwame ~  <3 CherBear ~ <3 -Author Kwame ~  <3 CherBear ~ <3 - Author Kwame ~  <3 CherBear ~ <3 -
Author Kwame ~  <3 CherBear ~ <3 - Author Kwame ~  <3 CherBear ~ <3 -Author Kwame ~  <3 CherBear ~ <3 - Author Kwame ~  <3 CherBear ~ <3 -
Author Kwame ~  <3 CherBear ~ <3 - Author Kwame ~  <3 CherBear ~ <3 -Author Kwame ~  <3 CherBear ~ <3 - Author Kwame ~  <3 CherBear ~ <3 -
Author Kwame ~  <3 CherBear ~ <3 - Author Kwame ~  <3 CherBear ~ <3 -Author Kwame ~  <3 CherBear ~ <3 - Author Kwame ~  <3 CherBear ~ <3 -
Author Kwame ~  <3 CherBear ~ <3 - Author Kwame ~  <3 CherBear ~ <3 -Author Kwame ~  <3 CherBear ~ <3 - Author Kwame ~  <3 CherBear ~ <3 -
Author Kwame ~  <3 CherBear ~ <3 - Author Kwame ~  <3 CherBear ~ <3 -Author Kwame ~  <3 CherBear ~ <3 - Author Kwame ~  <3 CherBear ~ <3 -
Author Kwame ~  <3 CherBear ~ <3 - Author Kwame ~  <3 CherBear ~ <3 -Author Kwame ~  <3 CherBear ~ <3 - Author Kwame ~  <3 CherBear ~ <3 -
Author Kwame ~  <3 CherBear ~ <3 - Author Kwame ~  <3 CherBear ~ <3 -Author Kwame ~  <3 CherBear ~ <3 - Author Kwame ~  <3 CherBear ~ <3 -
Author Kwame ~  <3 CherBear ~ <3 - Author Kwame ~  <3 CherBear ~ <3 -Author Kwame ~  <3 CherBear ~ <3 - Author Kwame ~  <3 CherBear ~ <3 -
Author Kwame ~  <3 CherBear ~ <3 - Author Kwame ~  <3 CherBear ~ <3 -Author Kwame ~  <3 CherBear ~ <3 - Author Kwame ~  <3 CherBear ~ <3 -
Author Kwame ~  <3 CherBear ~ <3 - Author Kwame ~  <3 CherBear ~ <3 -Author Kwame ~  <3 CherBear ~ <3 - Author Kwame ~  <3 CherBear ~ <3 -
Author Kwame ~  <3 CherBear ~ <3 - Author Kwame ~  <3 CherBear ~ <3 - Author Kwame ~  <3 CherBear ~ <3 - Author Kwame ~  <3 CherBear ~ <3 -
Author Kwame ~  <3 CherBear ~ <3 - Author Kwame ~  <3 CherBear ~ <3 -Author Kwame ~  <3 CherBear ~ <3 - Author Kwame ~  <3 CherBear ~ <3 -
Author Kwame ~  <3 CherBear ~ <3 - Author Kwame ~  <3 CherBear ~ <3 -Author Kwame ~  <3 CherBear ~ <3 - Author Kwame ~  <3 CherBear ~ <3 -
Author Kwame ~  <3 CherBear ~ <3 - Author Kwame ~  <3 CherBear ~ <3 -Author Kwame ~  <3 CherBear ~ <3 - Author Kwame ~  <3 CherBear ~ <3 -
Author Kwame ~  <3 CherBear ~ <3 - Author Kwame ~  <3 CherBear ~ <3 -Author Kwame ~  <3 CherBear ~ <3 - Author Kwame ~  <3 CherBear ~ <3 -
Author Kwame ~  <3 CherBear ~ <3 - Author Kwame ~  <3 CherBear ~ <3 -Author Kwame ~  <3 CherBear ~ <3 - Author Kwame ~  <3 CherBear ~ <3 -
Author Kwame ~  <3 CherBear ~ <3 - Author Kwame ~  <3 CherBear ~ <3 -Author Kwame ~  <3 CherBear ~ <3 - Author Kwame ~  <3 CherBear ~ <3 -
Author Kwame ~  <3 CherBear ~ <3 - Author Kwame ~  <3 CherBear ~ <3 -Author Kwame ~  <3 CherBear ~ <3 - Author Kwame ~  <3 CherBear ~ <3 -
Author Kwame ~  <3 CherBear ~ <3 - Author Kwame ~  <3 CherBear ~ <3 -Author Kwame ~  <3 CherBear ~ <3 - Author Kwame ~  <3 CherBear ~ <3 -
Author Kwame ~  <3 CherBear ~ <3 - Author Kwame ~  <3 CherBear ~ <3 -Author Kwame ~  <3 CherBear ~ <3 - Author Kwame ~  <3 CherBear ~ <3 -
Author Kwame ~  <3 CherBear ~ <3 - Author Kwame ~  <3 CherBear ~ <3 -Author Kwame ~  <3 CherBear ~ <3 - Author Kwame ~  <3 CherBear ~ <3 -
Author Kwame ~  <3 CherBear ~ <3 - Author Kwame ~  <3 CherBear ~ <3 -Author Kwame ~  <3 CherBear ~ <3 - Author Kwame ~  <3 CherBear ~ <3 -
Author Kwame ~  <3 CherBear ~ <3 - Author Kwame ~  <3 CherBear ~ <3 -Author Kwame ~  <3 CherBear ~ <3 - Author Kwame ~  <3 CherBear ~ <3 -
Author Kwame ~  <3 CherBear ~ <3 - Author Kwame ~  <3 CherBear ~ <3 -Author Kwame ~  <3 CherBear ~ <3 - Author Kwame ~  <3 CherBear ~ <3 -
Author Kwame ~  <3 CherBear ~ <3 - Author Kwame ~  <3 CherBear ~ <3 -Author Kwame ~  <3 CherBear ~ <3 - Author Kwame ~  <3 CherBear ~ <3 -
Author Kwame ~  <3 CherBear ~ <3 - Author Kwame ~  <3 CherBear ~ <3 - Author Kwame ~  <3 CherBear ~ <3 - Author Kwame ~  <3 CherBear ~ <3 -
Author Kwame ~  <3 CherBear ~ <3 - Author Kwame ~  <3 CherBear ~ <3 -Author Kwame ~  <3 CherBear ~ <3 - Author Kwame ~  <3 CherBear ~ <3 -
Author Kwame ~  <3 CherBear ~ <3 - Author Kwame ~  <3 CherBear ~ <3 -Author Kwame ~  <3 CherBear ~ <3 - Author Kwame ~  <3 CherBear ~ <3 -
Author Kwame ~  <3 CherBear ~ <3 - Author Kwame ~  <3 CherBear ~ <3 -Author Kwame ~  <3 CherBear ~ <3 - Author Kwame ~  <3 CherBear ~ <3 -
Author Kwame ~  <3 CherBear ~ <3 - Author Kwame ~  <3 CherBear ~ <3 -Author Kwame ~  <3 CherBear ~ <3 - Author Kwame ~  <3 CherBear ~ <3 -
Author Kwame ~  <3 CherBear ~ <3 - Author Kwame ~  <3 CherBear ~ <3 -Author Kwame ~  <3 CherBear ~ <3 - Author Kwame ~  <3 CherBear ~ <3 -
Author Kwame ~  <3 CherBear ~ <3 - Author Kwame ~  <3 CherBear ~ <3 -Author Kwame ~  <3 CherBear ~ <3 - Author Kwame ~  <3 CherBear ~ <3 -
Author Kwame ~  <3 CherBear ~ <3 - Author Kwame ~  <3 CherBear ~ <3 -Author Kwame ~  <3 CherBear ~ <3 - Author Kwame ~  <3 CherBear ~ <3 -
Author Kwame ~  <3 CherBear ~ <3 - Author Kwame ~  <3 CherBear ~ <3 -Author Kwame ~  <3 CherBear ~ <3 - Author Kwame ~  <3 CherBear ~ <3 -
Author Kwame ~  <3 CherBear ~ <3 - Author Kwame ~  <3 CherBear ~ <3 -Author Kwame ~  <3 CherBear ~ <3 - Author Kwame ~  <3 CherBear ~ <3 -
Author Kwame ~  <3 CherBear ~ <3 - Author Kwame ~  <3 CherBear ~ <3 -Author Kwame ~  <3 CherBear ~ <3 - Author Kwame ~  <3 CherBear ~ <3 -
Author Kwame ~  <3 CherBear ~ <3 - Author Kwame ~  <3 CherBear ~ <3 -Author Kwame ~  <3 CherBear ~ <3 - Author Kwame ~  <3 CherBear ~ <3 -
Author Kwame ~  <3 CherBear ~ <3 - Author Kwame ~  <3 CherBear ~ <3 -Author Kwame ~  <3 CherBear ~ <3 - Author Kwame ~  <3 CherBear ~ <3 -
Author Kwame ~  <3 CherBear ~ <3 - Author Kwame ~  <3 CherBear ~ <3 -Author Kwame ~  <3 CherBear ~ <3 - Author Kwame ~  <3 CherBear ~ <3 -
Author Kwame ~  <3 CherBear ~ <3 - Author Kwame ~  <3 CherBear ~ <3 -Author Kwame ~  <3 CherBear ~ <3 - Author Kwame ~  <3 CherBear ~ <3 -
<script>alert('Hey! its not maintenance time!')</script>
<script>window.location='../'</script>

